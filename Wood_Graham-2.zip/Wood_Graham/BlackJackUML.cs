﻿<?xml version="1.0" encoding="UTF-8"?>
<XPD:PROJECT xmlns:XPD="http://www.staruml.com" version="1">
<XPD:HEADER>
<XPD:SUBUNITS>
</XPD:SUBUNITS>
<XPD:PROFILES>
<XPD:PROFILE>UMLStandard</XPD:PROFILE>
</XPD:PROFILES>
</XPD:HEADER>
<XPD:BODY>
<XPD:OBJ name="DocumentElement" type="UMLProject" guid="r4jm53ELH0e/uTmA5zPrbgAA">
<XPD:ATTR name="Title" type="string">Untitled</XPD:ATTR>
<XPD:ATTR name="#OwnedElements" type="integer">5</XPD:ATTR>
<XPD:OBJ name="OwnedElements[0]" type="UMLModel" guid="n/gzUgZ9EUiDqaqvI+gwwAAA">
<XPD:ATTR name="Name" type="string">Use Case Model</XPD:ATTR>
<XPD:ATTR name="StereotypeProfile" type="string">UMLStandard</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">useCaseModel</XPD:ATTR>
<XPD:REF name="Namespace">r4jm53ELH0e/uTmA5zPrbgAA</XPD:REF>
<XPD:ATTR name="#OwnedDiagrams" type="integer">1</XPD:ATTR>
<XPD:OBJ name="OwnedDiagrams[0]" type="UMLUseCaseDiagram" guid="gCApb1sIgkmMdMWWVUzT+AAA">
<XPD:ATTR name="Name" type="string">Main</XPD:ATTR>
<XPD:REF name="DiagramOwner">n/gzUgZ9EUiDqaqvI+gwwAAA</XPD:REF>
<XPD:OBJ name="DiagramView" type="UMLUseCaseDiagramView" guid="1XLa2SNur0edKuHpD1CcYQAA">
<XPD:REF name="Model">gCApb1sIgkmMdMWWVUzT+AAA</XPD:REF>
<XPD:REF name="Diagram">gCApb1sIgkmMdMWWVUzT+AAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[1]" type="UMLModel" guid="BEu5uezhtEyAe98p1g5agQAA">
<XPD:ATTR name="Name" type="string">Analysis Model</XPD:ATTR>
<XPD:ATTR name="StereotypeProfile" type="string">UMLStandard</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">analysisModel</XPD:ATTR>
<XPD:REF name="Namespace">r4jm53ELH0e/uTmA5zPrbgAA</XPD:REF>
<XPD:ATTR name="#OwnedDiagrams" type="integer">1</XPD:ATTR>
<XPD:OBJ name="OwnedDiagrams[0]" type="UMLClassDiagram" guid="pVGg1R8DFkyDD4HmdJLqXAAA">
<XPD:ATTR name="Name" type="string">Main</XPD:ATTR>
<XPD:ATTR name="DefaultDiagram" type="boolean">True</XPD:ATTR>
<XPD:ATTR name="DiagramType" type="string">RobustnessDiagram</XPD:ATTR>
<XPD:REF name="DiagramOwner">BEu5uezhtEyAe98p1g5agQAA</XPD:REF>
<XPD:OBJ name="DiagramView" type="UMLClassDiagramView" guid="NuMgarE+R0O90lDFi4JNogAA">
<XPD:REF name="Model">pVGg1R8DFkyDD4HmdJLqXAAA</XPD:REF>
<XPD:REF name="Diagram">pVGg1R8DFkyDD4HmdJLqXAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[2]" type="UMLModel" guid="L4iAr+GseUKAdqRPNqYtnAAA">
<XPD:ATTR name="Name" type="string">Design Model</XPD:ATTR>
<XPD:ATTR name="StereotypeProfile" type="string">UMLStandard</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">designModel</XPD:ATTR>
<XPD:REF name="Namespace">r4jm53ELH0e/uTmA5zPrbgAA</XPD:REF>
<XPD:ATTR name="#OwnedDiagrams" type="integer">1</XPD:ATTR>
<XPD:OBJ name="OwnedDiagrams[0]" type="UMLClassDiagram" guid="m3A6bfGmRU2Y9R1f+RNPZQAA">
<XPD:ATTR name="Name" type="string">Main</XPD:ATTR>
<XPD:ATTR name="DefaultDiagram" type="boolean">True</XPD:ATTR>
<XPD:REF name="DiagramOwner">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:OBJ name="DiagramView" type="UMLClassDiagramView" guid="uemMAbtDEUGwyawyBUewzQAA">
<XPD:REF name="Model">m3A6bfGmRU2Y9R1f+RNPZQAA</XPD:REF>
<XPD:REF name="Diagram">m3A6bfGmRU2Y9R1f+RNPZQAA</XPD:REF>
<XPD:ATTR name="#OwnedViews" type="integer">16</XPD:ATTR>
<XPD:OBJ name="OwnedViews[0]" type="UMLClassView" guid="FR9H0059VUGXkR0Qu7VjbwAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">20</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">248</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">101</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">116</XPD:ATTR>
<XPD:REF name="Model">glQJGmntnkGRWkFj7fSTjwAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="1mUjEhY2SEaC2/PPidkJugAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="nl/pCevUDEK/nm3fwsV2YgAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">CardGames</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="ttbxtG+MeUykaIcPAd0ThwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="drsyzRV1j0OVsdVm8EMc8wAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="x+23ZMSbN0mXph8S0PjEqwAA">
<XPD:REF name="Model">glQJGmntnkGRWkFj7fSTjwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="4U0Kxw7JgE69wMAIU56PvQAA">
<XPD:REF name="Model">glQJGmntnkGRWkFj7fSTjwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="39hL2PRWd0Onb32erBB25wAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">glQJGmntnkGRWkFj7fSTjwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[1]" type="UMLClassView" guid="IyY1h1Dvs02E+9S94QyhnAAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">216</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">472</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">120</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">251</XPD:ATTR>
<XPD:REF name="Model">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="LIqlZ5ZaSUGhs2nJZPWDvgAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="CiJIbSqeS0ClUzEyY4zNmwAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">BlackJack</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="wxSgQW1GkU2y9C0VyV+5MQAA">
<XPD:ATTR name="Text" type="string">&lt;&lt;Boundary&gt;&gt;</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="9xJLdMU0/UCM3ZXRA8uRFAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="urfp0rIjY0mkjgu6NqTJ7gAA">
<XPD:REF name="Model">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="OIe6oaG7oE22CXLxv9tFEAAA">
<XPD:REF name="Model">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="s/9tJpjzvEWCK2zt02lVcwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[2]" type="UMLClassView" guid="MCcJpX+BwEyUpXaNVpB6egAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">540</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">480</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">145</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">173</XPD:ATTR>
<XPD:REF name="Model">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="bZLbMyAP2EKpL1wryArPLQAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="73wv7f/Q5EevNLSdweBuqQAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">Deck</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="vtB+Ufb9dUqVtTScFFS20AAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="+rVW85q5bkmPstjUF6X41QAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="TKqrvbl2c0CX1f8LOwWkkgAA">
<XPD:REF name="Model">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="o/IlXRgl6E6bhYnrKvuN6QAA">
<XPD:REF name="Model">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="zCAkOfHspEGzCqf3duyD0gAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[3]" type="UMLAssociationView" guid="ss0IdDacT0SP3jfCV8LrOAAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">111,363;216,513</XPD:ATTR>
<XPD:REF name="Model">cGLVTdw3r0uknAX2M2e6ggAA</XPD:REF>
<XPD:REF name="Head">IyY1h1Dvs02E+9S94QyhnAAA</XPD:REF>
<XPD:REF name="Tail">FR9H0059VUGXkR0Qu7VjbwAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="qI78ghzbbkCZPEYI9peBOwAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:ATTR name="Text" type="string">bj</XPD:ATTR>
<XPD:REF name="Model">cGLVTdw3r0uknAX2M2e6ggAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="AJhZt2qdAEWSIPnY+pdcRAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">cGLVTdw3r0uknAX2M2e6ggAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="ODIhTgyyHUCsLEAg5oxl4QAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">cGLVTdw3r0uknAX2M2e6ggAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadRoleNameLabel" type="EdgeLabelView" guid="c23DibYqDUy3AkqHM7wYnQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">LJlqvxfIm0iIqA/FfUTD0gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailRoleNameLabel" type="EdgeLabelView" guid="1GYytdXbo06hLbMSfpDCmwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">mCpgxhckTE2Zt+aPkW8b2gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadMultiplicityLabel" type="EdgeLabelView" guid="tf6Y4BgYzUeH7ysdOeJ0egAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">LJlqvxfIm0iIqA/FfUTD0gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailMultiplicityLabel" type="EdgeLabelView" guid="/Q7hQJO9GkuFhciAqqk43QAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">mCpgxhckTE2Zt+aPkW8b2gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadPropertyLabel" type="EdgeLabelView" guid="QbIG2A+D0ESTYFOPDh1PiwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">LJlqvxfIm0iIqA/FfUTD0gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailPropertyLabel" type="EdgeLabelView" guid="zvx86WnVFEOc7KCQoEebewAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">mCpgxhckTE2Zt+aPkW8b2gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadQualifierCompartment" type="UMLQualifierCompartmentView" guid="+LKH8rR0+Eygd7UsO77FaAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">LJlqvxfIm0iIqA/FfUTD0gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailQualifierCompartment" type="UMLQualifierCompartmentView" guid="J3/I531lbE+o6PNh2SxJLwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">mCpgxhckTE2Zt+aPkW8b2gAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[4]" type="UMLClassView" guid="c3hK6BD+DEeWH1did8FqOwAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">260</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">108</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">152</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">173</XPD:ATTR>
<XPD:REF name="Model">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="PltCGq8kIUWJ70TzrtbHOQAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="thj2vQKsR0O/n+CWVFY9twAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">BJPlayer</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="8Cnt/YXcAkWpyCE5aSikIQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="D/NBadnRfEqico5C2KT0bAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="jB7LJLIvi0WnYZN2+VoXlgAA">
<XPD:REF name="Model">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="tTQyfwlChU2tHnzVdu0DggAA">
<XPD:REF name="Model">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="cGoP0G/x8kuQGpgp8o+5YAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[5]" type="UMLClassView" guid="lKnhGh/MeUqRVuvJQbTWKgAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">568</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">92</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">93</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">97</XPD:ATTR>
<XPD:REF name="Model">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="U5L7tkYhsECAfD3c3r7IqwAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="tTvARiQji02ofPO2b04huQAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">BJCustomer</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="HNTEDdKH4kGEQkGKSdUOdQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="MOLwKvG1jEaeQtPMgGzJJwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="9tGozfmAn0qgeJdn13c/pAAA">
<XPD:REF name="Model">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="YIfcH6STlk2N8/gCbLW6oAAA">
<XPD:REF name="Model">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="jPhfkxHb3kiF6mbctiyKOAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[6]" type="UMLClassView" guid="B4diEkk+nkmKtREidfG/QwAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">564</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">272</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">100</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">109</XPD:ATTR>
<XPD:REF name="Model">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="lqY6PC4XskCBoB5p4QJ64gAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="c4aQvynJsE+A0fNh3gteoQAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">BJDealer</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="Bqnpln2D0EmsAsXpPONnDQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="OOkDmIvHm0CPGLrvgxT+8AAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="c8Bx0ct+GUS5OPm7ryHIgwAA">
<XPD:REF name="Model">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="+OqjNPW7Jk2oxVK7SP/1wgAA">
<XPD:REF name="Model">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="hJYIYa0rGUSJAyqCSL8xwAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[7]" type="UMLGeneralizationView" guid="7Gwbl0tdxEW1kU5oAG9AewAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">568,149;411,179</XPD:ATTR>
<XPD:REF name="Model">g+WROHXs/0OWVCfl7EonzQAA</XPD:REF>
<XPD:REF name="Head">c3hK6BD+DEeWH1did8FqOwAA</XPD:REF>
<XPD:REF name="Tail">lKnhGh/MeUqRVuvJQbTWKgAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="RMAPnUFxoUeZieCOCw8bfwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">g+WROHXs/0OWVCfl7EonzQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="n2s5dL6kuEiBIcoyUqkNHQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">g+WROHXs/0OWVCfl7EonzQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="rQyiuvEHnkqvtT7/0B1xnAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">g+WROHXs/0OWVCfl7EonzQAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[8]" type="UMLGeneralizationView" guid="TtpQFxZYckueADg2QRUKHAAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">564,303;411,230</XPD:ATTR>
<XPD:REF name="Model">mh3oO2GSREWNQdysmIHJwAAA</XPD:REF>
<XPD:REF name="Head">c3hK6BD+DEeWH1did8FqOwAA</XPD:REF>
<XPD:REF name="Tail">B4diEkk+nkmKtREidfG/QwAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="TAwFEpDcIU+4HGQaTlQhxAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">mh3oO2GSREWNQdysmIHJwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="VRodPfIeUEaqXJCI4KzaOAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">mh3oO2GSREWNQdysmIHJwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="12s0wS+XgkOvWRVU/N2D+gAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">mh3oO2GSREWNQdysmIHJwAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[9]" type="UMLAssociationView" guid="GqYXSyKOsEK9wUizD5EdXQAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">335,516;578,188</XPD:ATTR>
<XPD:REF name="Model">NiEFldmAPU+SwsJJ+ZS6WQAA</XPD:REF>
<XPD:REF name="Head">lKnhGh/MeUqRVuvJQbTWKgAA</XPD:REF>
<XPD:REF name="Tail">IyY1h1Dvs02E+9S94QyhnAAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="oFQsTF98FUKfHvt3kO4ulQAA">
<XPD:ATTR name="Alpha" type="real">-3.86377807952635</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">67.468511173732</XPD:ATTR>
<XPD:ATTR name="Text" type="string">Customer</XPD:ATTR>
<XPD:REF name="Model">NiEFldmAPU+SwsJJ+ZS6WQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="rWEx+v7RhEO5WP4qrBj0GQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">NiEFldmAPU+SwsJJ+ZS6WQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="wGu/AdDe9U6WUjrwZ5LzYgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">NiEFldmAPU+SwsJJ+ZS6WQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadRoleNameLabel" type="EdgeLabelView" guid="gUyl07IpmEaCr8JCXVE9UAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">XqgiYbwL50yXN3bmSv92NAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailRoleNameLabel" type="EdgeLabelView" guid="+a17yx8CCECBWf/I77qbWAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Gbq2t5XJJkmLtSL9M//h+AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadMultiplicityLabel" type="EdgeLabelView" guid="bxx3+7UQSkeSz4AxxIZcoQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">XqgiYbwL50yXN3bmSv92NAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailMultiplicityLabel" type="EdgeLabelView" guid="exQMNCbsLkSLCbCfjbM8HAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Gbq2t5XJJkmLtSL9M//h+AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadPropertyLabel" type="EdgeLabelView" guid="lNyErVwOrUan58wUIq/7OAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">XqgiYbwL50yXN3bmSv92NAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailPropertyLabel" type="EdgeLabelView" guid="UN6V34aZiE+hrnM//8BRgAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Gbq2t5XJJkmLtSL9M//h+AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadQualifierCompartment" type="UMLQualifierCompartmentView" guid="wG0ET3t9A0aMG4v+6nITWwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">XqgiYbwL50yXN3bmSv92NAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailQualifierCompartment" type="UMLQualifierCompartmentView" guid="5KRz9uSQtkqJPvsc3oGIQAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">Gbq2t5XJJkmLtSL9M//h+AAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[10]" type="UMLAssociationView" guid="gB7bsMzdtE2xF6cfiL1a6AAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">335,549;564,365</XPD:ATTR>
<XPD:REF name="Model">Rz+AOm/xnUmGeNIDGgon0AAA</XPD:REF>
<XPD:REF name="Head">B4diEkk+nkmKtREidfG/QwAA</XPD:REF>
<XPD:REF name="Tail">IyY1h1Dvs02E+9S94QyhnAAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="QzCGPsYMB0+SE2ifYg9V1gAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:ATTR name="Text" type="string">Dealer</XPD:ATTR>
<XPD:REF name="Model">Rz+AOm/xnUmGeNIDGgon0AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="jtul7VJvFkeHzx//taISPgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">Rz+AOm/xnUmGeNIDGgon0AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="hUELIjZPn0yvInWN0TJEdgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">Rz+AOm/xnUmGeNIDGgon0AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadRoleNameLabel" type="EdgeLabelView" guid="NEFzYir0bUeDscTauUl5RwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">1BZo7DAnYUOsYJwR55ZXfAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailRoleNameLabel" type="EdgeLabelView" guid="jDlcI7lB70yppAXy9+jeyAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Ya+FdbYPL0GferQ0TMtpXgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadMultiplicityLabel" type="EdgeLabelView" guid="oHg1zDj3mkKGTvsfrkdVqwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">1BZo7DAnYUOsYJwR55ZXfAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailMultiplicityLabel" type="EdgeLabelView" guid="Wl4z/bqi00amLHp1zHKcFAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Ya+FdbYPL0GferQ0TMtpXgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadPropertyLabel" type="EdgeLabelView" guid="Aa3Rb0VJoEqb26n9eEXQIQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">1BZo7DAnYUOsYJwR55ZXfAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailPropertyLabel" type="EdgeLabelView" guid="33VWE688rEutYJ+8BEW2YwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Ya+FdbYPL0GferQ0TMtpXgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadQualifierCompartment" type="UMLQualifierCompartmentView" guid="gdwzf19NZEOTLM9BBL4Q/AAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">1BZo7DAnYUOsYJwR55ZXfAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailQualifierCompartment" type="UMLQualifierCompartmentView" guid="f/ZOVDMSQEebv/GOoZM7cQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">Ya+FdbYPL0GferQ0TMtpXgAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[11]" type="UMLDependencyView" guid="CO+QoU1W00WaE+3Je0VtFgAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">335,591;540,572</XPD:ATTR>
<XPD:REF name="Model">e/PVmFInJ0SAUoK7sX5kIgAA</XPD:REF>
<XPD:REF name="Head">MCcJpX+BwEyUpXaNVpB6egAA</XPD:REF>
<XPD:REF name="Tail">IyY1h1Dvs02E+9S94QyhnAAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="zpIUqPOe0kuYADmaBrWEEQAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:ATTR name="Text" type="string">deck</XPD:ATTR>
<XPD:REF name="Model">e/PVmFInJ0SAUoK7sX5kIgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="JWZ4SiDcQ0uk3vJgf+Bn9QAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">e/PVmFInJ0SAUoK7sX5kIgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="pEeY6g0VmkGQ8Swssqy0PwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">e/PVmFInJ0SAUoK7sX5kIgAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[12]" type="UMLClassView" guid="YZuKxT4b3UyecSca1VwyEAAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">984</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">268</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">100</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">120</XPD:ATTR>
<XPD:REF name="Model">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
<XPD:OBJ name="NameCompartment" type="UMLNameCompartmentView" guid="FfZyc4n0HkikPM6kd54JDAAA">
<XPD:OBJ name="NameLabel" type="LabelView" guid="yStviGvDlUyfFaLOuJgfoAAA">
<XPD:ATTR name="FontStyle" type="integer">1</XPD:ATTR>
<XPD:ATTR name="Text" type="string">Card</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="LabelView" guid="ri4dIX3N0kymtKQ4DxblVwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="LabelView" guid="Y6rAwi4stEeN2hj9zVy8GQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="AttributeCompartment" type="UMLAttributeCompartmentView" guid="Ozd9mQK670aNTwdHwgYciwAA">
<XPD:REF name="Model">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OperationCompartment" type="UMLOperationCompartmentView" guid="uyKKD0uw5EGdHy/oz6sHLgAA">
<XPD:REF name="Model">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TemplateParameterCompartment" type="UMLTemplateParameterCompartmentView" guid="njnOslnvw0+36aS3moeW+wAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:REF name="Model">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[13]" type="UMLAssociationView" guid="a3wy3sazrUqSvLyo5XpYpAAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">684,525;984,355</XPD:ATTR>
<XPD:REF name="Model">SyZtRDBrmUSKwK0OcttDYwAA</XPD:REF>
<XPD:REF name="Head">YZuKxT4b3UyecSca1VwyEAAA</XPD:REF>
<XPD:REF name="Tail">MCcJpX+BwEyUpXaNVpB6egAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="ovlVjznwzE23F9+FlwGtAgAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:ATTR name="Text" type="string">deck</XPD:ATTR>
<XPD:REF name="Model">SyZtRDBrmUSKwK0OcttDYwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="BEd7ffwI0ESgoDojenj/1gAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="Text" type="string">&lt;&lt;object[]&gt;&gt;</XPD:ATTR>
<XPD:REF name="Model">SyZtRDBrmUSKwK0OcttDYwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="OMj5iDknvk+is9YibMXksgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">SyZtRDBrmUSKwK0OcttDYwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadRoleNameLabel" type="EdgeLabelView" guid="WXHUL8QQ5EWkkVhhkRA4gwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">qb4uALT++k2UEzNykaLDhgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailRoleNameLabel" type="EdgeLabelView" guid="xJWxJUn0lEiRcwUt3jr9QgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">ViF76epeqka5NAanwRnmnwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadMultiplicityLabel" type="EdgeLabelView" guid="iNKyf5zql0KtK1+NsRebvAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">qb4uALT++k2UEzNykaLDhgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailMultiplicityLabel" type="EdgeLabelView" guid="DPKgqnIn806hBMNKaJgHZQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">ViF76epeqka5NAanwRnmnwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadPropertyLabel" type="EdgeLabelView" guid="knvqMYWkv0y0nwWIQkXnWQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">qb4uALT++k2UEzNykaLDhgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailPropertyLabel" type="EdgeLabelView" guid="hkZn11Y9s0Khw+2jFKhM+wAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">ViF76epeqka5NAanwRnmnwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadQualifierCompartment" type="UMLQualifierCompartmentView" guid="J+cMULQfN0aFPAFmb91+QQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">qb4uALT++k2UEzNykaLDhgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailQualifierCompartment" type="UMLQualifierCompartmentView" guid="eikXJLI0FE6N7B0OrUFLwQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">ViF76epeqka5NAanwRnmnwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[14]" type="UMLAssociationView" guid="2JEFPqiLOkSVJaTLgF2xTQAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">399,280;548,480</XPD:ATTR>
<XPD:REF name="Model">uUZFKckQTku1vkqZvf1lWQAA</XPD:REF>
<XPD:REF name="Head">MCcJpX+BwEyUpXaNVpB6egAA</XPD:REF>
<XPD:REF name="Tail">c3hK6BD+DEeWH1did8FqOwAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="k8tN76vh3kiMI2N8PL0jvAAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:ATTR name="Text" type="string">deck</XPD:ATTR>
<XPD:REF name="Model">uUZFKckQTku1vkqZvf1lWQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="zx26Qg5TD0iCcUhCfhxAbwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">uUZFKckQTku1vkqZvf1lWQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="whlqCGi8cUu5E7TRozYDtwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">uUZFKckQTku1vkqZvf1lWQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadRoleNameLabel" type="EdgeLabelView" guid="TSiI2xnnKkuh7UH+WUS2nwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">MdaWZ6iawkuz5hYsqJGPqQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailRoleNameLabel" type="EdgeLabelView" guid="xsoduHNnLEybAduRu4tIPQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">hrsZDDUzxUieDAdbHLn7JQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadMultiplicityLabel" type="EdgeLabelView" guid="MjSwBl4OL0mgu0xK8U+oKwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">MdaWZ6iawkuz5hYsqJGPqQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailMultiplicityLabel" type="EdgeLabelView" guid="b5XTbZpqR0qO4Xt+p8Hd9AAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">hrsZDDUzxUieDAdbHLn7JQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadPropertyLabel" type="EdgeLabelView" guid="n9rmBL/wmk+aO2Duiey9uAAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">MdaWZ6iawkuz5hYsqJGPqQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailPropertyLabel" type="EdgeLabelView" guid="8r5BHVPJ20ydsk1BObZMJgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">hrsZDDUzxUieDAdbHLn7JQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadQualifierCompartment" type="UMLQualifierCompartmentView" guid="1daLgQoAcE2D2xEzksZATgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">MdaWZ6iawkuz5hYsqJGPqQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailQualifierCompartment" type="UMLQualifierCompartmentView" guid="85FUDCMm/k+4yGR48aLtBwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">hrsZDDUzxUieDAdbHLn7JQAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedViews[15]" type="UMLAssociationView" guid="JIFaop+zgUeuSFnKsD79SgAA">
<XPD:ATTR name="LineColor" type="string">clMaroon</XPD:ATTR>
<XPD:ATTR name="FillColor" type="string">$00B9FFFF</XPD:ATTR>
<XPD:ATTR name="Points" type="Points">411,208;984,318</XPD:ATTR>
<XPD:REF name="Model">9wyc9DSsgkKgk4tmPYVA8QAA</XPD:REF>
<XPD:REF name="Head">YZuKxT4b3UyecSca1VwyEAAA</XPD:REF>
<XPD:REF name="Tail">c3hK6BD+DEeWH1did8FqOwAA</XPD:REF>
<XPD:OBJ name="NameLabel" type="EdgeLabelView" guid="QacInGxedkm2cXyIwD3O9wAA">
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:ATTR name="Text" type="string">playerHand[]</XPD:ATTR>
<XPD:REF name="Model">9wyc9DSsgkKgk4tmPYVA8QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="StereotypeLabel" type="EdgeLabelView" guid="3+eUJPrYfEqNS/J3AKympgAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:REF name="Model">9wyc9DSsgkKgk4tmPYVA8QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="PropertyLabel" type="EdgeLabelView" guid="mex810CVq0mMssz3tpWv1wAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-1.5707963267949</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">15</XPD:ATTR>
<XPD:REF name="Model">9wyc9DSsgkKgk4tmPYVA8QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadRoleNameLabel" type="EdgeLabelView" guid="gvZAXGmY1kOXMJsFOnODgwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">3+Qy5bIo1EGf8kRnu0utLgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailRoleNameLabel" type="EdgeLabelView" guid="YekCHEWIaE2xU0mmEKtDPwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">30</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Zq/mZjg0gUqF2/o9/OEjrgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadMultiplicityLabel" type="EdgeLabelView" guid="WUP/Dd2xh0WUPGlmpaclcQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">3+Qy5bIo1EGf8kRnu0utLgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailMultiplicityLabel" type="EdgeLabelView" guid="hLiGN3jZH0uC+aipbjMw2gAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.523598775598299</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">25</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Zq/mZjg0gUqF2/o9/OEjrgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadPropertyLabel" type="EdgeLabelView" guid="P4SZF/RZIEagvEGHtAzptwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">-0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epHead</XPD:ATTR>
<XPD:REF name="Model">3+Qy5bIo1EGf8kRnu0utLgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailPropertyLabel" type="EdgeLabelView" guid="G2f8AG2i1kyI7qgNteTHFwAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Alpha" type="real">0.785398163397448</XPD:ATTR>
<XPD:ATTR name="Distance" type="real">40</XPD:ATTR>
<XPD:ATTR name="EdgePosition" type="EdgePositionKind">epTail</XPD:ATTR>
<XPD:REF name="Model">Zq/mZjg0gUqF2/o9/OEjrgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="HeadQualifierCompartment" type="UMLQualifierCompartmentView" guid="Hs1uk9odAk6K5B1NGeljNQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">3+Qy5bIo1EGf8kRnu0utLgAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="TailQualifierCompartment" type="UMLQualifierCompartmentView" guid="OLVUW7oMJkGG8btVCvQMVQAA">
<XPD:ATTR name="Visible" type="boolean">False</XPD:ATTR>
<XPD:ATTR name="Left" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Top" type="integer">-1000</XPD:ATTR>
<XPD:ATTR name="Width" type="integer">50</XPD:ATTR>
<XPD:ATTR name="Height" type="integer">8</XPD:ATTR>
<XPD:REF name="Model">Zq/mZjg0gUqF2/o9/OEjrgAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
<XPD:ATTR name="#OwnedElements" type="integer">23</XPD:ATTR>
<XPD:OBJ name="OwnedElements[0]" type="UMLClass" guid="glQJGmntnkGRWkFj7fSTjwAA">
<XPD:ATTR name="Name" type="string">CardGames</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">FR9H0059VUGXkR0Qu7VjbwAA</XPD:REF>
<XPD:REF name="Views[1]">x+23ZMSbN0mXph8S0PjEqwAA</XPD:REF>
<XPD:REF name="Views[2]">4U0Kxw7JgE69wMAIU56PvQAA</XPD:REF>
<XPD:REF name="Views[3]">39hL2PRWd0Onb32erBB25wAA</XPD:REF>
<XPD:ATTR name="#Operations" type="integer">1</XPD:ATTR>
<XPD:OBJ name="Operations[0]" type="UMLOperation" guid="72VhQETTt0aTM0qP5FWw9wAA">
<XPD:ATTR name="Name" type="string">go</XPD:ATTR>
<XPD:REF name="Owner">glQJGmntnkGRWkFj7fSTjwAA</XPD:REF>
</XPD:OBJ>
<XPD:ATTR name="#Associations" type="integer">1</XPD:ATTR>
<XPD:REF name="Associations[0]">mCpgxhckTE2Zt+aPkW8b2gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[1]" type="UMLClass" guid="86O1RveyFk+lo6p6kHuP4QAA">
<XPD:ATTR name="Name" type="string">BlackJack</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">Boundary</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">IyY1h1Dvs02E+9S94QyhnAAA</XPD:REF>
<XPD:REF name="Views[1]">urfp0rIjY0mkjgu6NqTJ7gAA</XPD:REF>
<XPD:REF name="Views[2]">OIe6oaG7oE22CXLxv9tFEAAA</XPD:REF>
<XPD:REF name="Views[3]">s/9tJpjzvEWCK2zt02lVcwAA</XPD:REF>
<XPD:ATTR name="#ClientDependencies" type="integer">1</XPD:ATTR>
<XPD:REF name="ClientDependencies[0]">e/PVmFInJ0SAUoK7sX5kIgAA</XPD:REF>
<XPD:ATTR name="#Operations" type="integer">10</XPD:ATTR>
<XPD:OBJ name="Operations[0]" type="UMLOperation" guid="eY46jrcbWUOfYFaIwkOHawAA">
<XPD:ATTR name="Name" type="string">Go</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[1]" type="UMLOperation" guid="ecx7X5PtqUqVl/JEt1VaBQAA">
<XPD:ATTR name="Name" type="string">PlayOneGame</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[2]" type="UMLOperation" guid="O0gDoq0FtEW8hQv6AUC0xAAA">
<XPD:ATTR name="Name" type="string">GetBetFromUser</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[3]" type="UMLOperation" guid="lxi3v+NzXUmKrpiZONEDEQAA">
<XPD:ATTR name="Name" type="string">CustomerTurn</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[4]" type="UMLOperation" guid="ZtFh/QoRXky47udE8Eb2pQAA">
<XPD:ATTR name="Name" type="string">DealerTurn</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[5]" type="UMLOperation" guid="iVj2GOUSOUObFu0Ay09hQAAA">
<XPD:ATTR name="Name" type="string">CheckSurrender</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[6]" type="UMLOperation" guid="XvdEGirQukOQ8QnSgCnr3AAA">
<XPD:ATTR name="Name" type="string">TestForNatural21</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[7]" type="UMLOperation" guid="b4q59hSqAk+eJPQcCe5tUgAA">
<XPD:ATTR name="Name" type="string">CheckMoreGame</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[8]" type="UMLOperation" guid="pLw0KoCeBk+CfZQaz/5BLQAA">
<XPD:ATTR name="Name" type="string">DealCards</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[9]" type="UMLOperation" guid="44XoXRhowUeroOI2ttuNrAAA">
<XPD:ATTR name="Name" type="string">DetermineWinner</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:ATTR name="#Associations" type="integer">4</XPD:ATTR>
<XPD:REF name="Associations[0]">LJlqvxfIm0iIqA/FfUTD0gAA</XPD:REF>
<XPD:REF name="Associations[1]">Gbq2t5XJJkmLtSL9M//h+AAA</XPD:REF>
<XPD:REF name="Associations[2]">Ya+FdbYPL0GferQ0TMtpXgAA</XPD:REF>
<XPD:REF name="Associations[3]">uWF1/tSKf0qNbl645NpAQgAA</XPD:REF>
<XPD:ATTR name="#Attributes" type="integer">5</XPD:ATTR>
<XPD:OBJ name="Attributes[0]" type="UMLAttribute" guid="Yi+IRj6L9UmUu9BdFvYKawAA">
<XPD:ATTR name="Name" type="string">Deck deck</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[1]" type="UMLAttribute" guid="b7K1GNcT4EGiJWkYCw163AAA">
<XPD:ATTR name="Name" type="string">BJDealer Dealer</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[2]" type="UMLAttribute" guid="2G4IqxZEe02walOlCVnJPQAA">
<XPD:ATTR name="Name" type="string">BJCustomer Customer</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[3]" type="UMLAttribute" guid="7XiNs3D8gUyEGHhnwOA40gAA">
<XPD:ATTR name="Name" type="string">Decimal bet</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[4]" type="UMLAttribute" guid="jB2t9UtN1UKFu6R15Y5cUgAA">
<XPD:ATTR name="Name" type="string">string response</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[2]" type="UMLClass" guid="DlwK1IcLzkGj9LEPfQ5ZwAAA">
<XPD:ATTR name="Name" type="string">Deck</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">MCcJpX+BwEyUpXaNVpB6egAA</XPD:REF>
<XPD:REF name="Views[1]">TKqrvbl2c0CX1f8LOwWkkgAA</XPD:REF>
<XPD:REF name="Views[2]">o/IlXRgl6E6bhYnrKvuN6QAA</XPD:REF>
<XPD:REF name="Views[3]">zCAkOfHspEGzCqf3duyD0gAA</XPD:REF>
<XPD:ATTR name="#SupplierDependencies" type="integer">1</XPD:ATTR>
<XPD:REF name="SupplierDependencies[0]">e/PVmFInJ0SAUoK7sX5kIgAA</XPD:REF>
<XPD:ATTR name="#Operations" type="integer">3</XPD:ATTR>
<XPD:OBJ name="Operations[0]" type="UMLOperation" guid="oHQdVV+i20ip5d/4QHIfbwAA">
<XPD:ATTR name="Name" type="string">Shuffle</XPD:ATTR>
<XPD:REF name="Owner">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[1]" type="UMLOperation" guid="w4jBzBIFAkeQrvM3+Els5QAA">
<XPD:ATTR name="Name" type="string">draw</XPD:ATTR>
<XPD:REF name="Owner">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[2]" type="UMLOperation" guid="8yi7Qc48H0W22R14DPGkrwAA">
<XPD:ATTR name="Name" type="string">ReturnCard</XPD:ATTR>
<XPD:REF name="Owner">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:ATTR name="#Associations" type="integer">4</XPD:ATTR>
<XPD:REF name="Associations[0]">ZkcT0q7WVEGlZ2ZwryD5VgAA</XPD:REF>
<XPD:REF name="Associations[1]">VQB9Yl+FHEem6koJ2FySgAAA</XPD:REF>
<XPD:REF name="Associations[2]">ViF76epeqka5NAanwRnmnwAA</XPD:REF>
<XPD:REF name="Associations[3]">MdaWZ6iawkuz5hYsqJGPqQAA</XPD:REF>
<XPD:ATTR name="#Attributes" type="integer">3</XPD:ATTR>
<XPD:OBJ name="Attributes[0]" type="UMLAttribute" guid="NEx5YbZ3CkCcyqX2VGCeCgAA">
<XPD:ATTR name="Name" type="string">Card deck[]</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[1]" type="UMLAttribute" guid="TFco0TDuvk++rG/uaPGLpQAA">
<XPD:ATTR name="Name" type="string">int topCardIndex</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[2]" type="UMLAttribute" guid="ZuAKk+pVhE2tKwof2p82RAAA">
<XPD:ATTR name="Name" type="string">Random r</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[3]" type="UMLAssociation" guid="cGLVTdw3r0uknAX2M2e6ggAA">
<XPD:ATTR name="Name" type="string">bj</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">ss0IdDacT0SP3jfCV8LrOAAA</XPD:REF>
<XPD:REF name="Views[1]">qI78ghzbbkCZPEYI9peBOwAA</XPD:REF>
<XPD:REF name="Views[2]">AJhZt2qdAEWSIPnY+pdcRAAA</XPD:REF>
<XPD:REF name="Views[3]">ODIhTgyyHUCsLEAg5oxl4QAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="mCpgxhckTE2Zt+aPkW8b2gAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">cGLVTdw3r0uknAX2M2e6ggAA</XPD:REF>
<XPD:REF name="Participant">glQJGmntnkGRWkFj7fSTjwAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">1GYytdXbo06hLbMSfpDCmwAA</XPD:REF>
<XPD:REF name="Views[1]">zvx86WnVFEOc7KCQoEebewAA</XPD:REF>
<XPD:REF name="Views[2]">/Q7hQJO9GkuFhciAqqk43QAA</XPD:REF>
<XPD:REF name="Views[3]">J3/I531lbE+o6PNh2SxJLwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="LJlqvxfIm0iIqA/FfUTD0gAA">
<XPD:REF name="Association">cGLVTdw3r0uknAX2M2e6ggAA</XPD:REF>
<XPD:REF name="Participant">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">c23DibYqDUy3AkqHM7wYnQAA</XPD:REF>
<XPD:REF name="Views[1]">QbIG2A+D0ESTYFOPDh1PiwAA</XPD:REF>
<XPD:REF name="Views[2]">tf6Y4BgYzUeH7ysdOeJ0egAA</XPD:REF>
<XPD:REF name="Views[3]">+LKH8rR0+Eygd7UsO77FaAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[4]" type="UMLClass" guid="n2kB6QWlskWNMBwmO7q30AAA">
<XPD:ATTR name="Name" type="string">BJPlayer</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">c3hK6BD+DEeWH1did8FqOwAA</XPD:REF>
<XPD:REF name="Views[1]">jB7LJLIvi0WnYZN2+VoXlgAA</XPD:REF>
<XPD:REF name="Views[2]">tTQyfwlChU2tHnzVdu0DggAA</XPD:REF>
<XPD:REF name="Views[3]">cGoP0G/x8kuQGpgp8o+5YAAA</XPD:REF>
<XPD:ATTR name="#Generalizations" type="integer">1</XPD:ATTR>
<XPD:REF name="Generalizations[0]">UBcsmxqn7k2T/i9YSQ+qJwAA</XPD:REF>
<XPD:ATTR name="#Specializations" type="integer">2</XPD:ATTR>
<XPD:REF name="Specializations[0]">g+WROHXs/0OWVCfl7EonzQAA</XPD:REF>
<XPD:REF name="Specializations[1]">mh3oO2GSREWNQdysmIHJwAAA</XPD:REF>
<XPD:ATTR name="#Operations" type="integer">4</XPD:ATTR>
<XPD:OBJ name="Operations[0]" type="UMLOperation" guid="GoUkm/bwY06hUoYYagPjDQAA">
<XPD:ATTR name="Name" type="string">draw</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[1]" type="UMLOperation" guid="j6e6eM16wkWkzzE8GUmGjwAA">
<XPD:ATTR name="Name" type="string">ReturnCardsToDeck</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[2]" type="UMLOperation" guid="6slFO9lrCE2/OiarAYpx7AAA">
<XPD:ATTR name="Name" type="string">DisplayCards</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Operations[3]" type="UMLOperation" guid="ZkThSEQmO0eCpeKkzfjsTgAA">
<XPD:ATTR name="Name" type="string">CalculateHandValue</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:ATTR name="#Associations" type="integer">2</XPD:ATTR>
<XPD:REF name="Associations[0]">hrsZDDUzxUieDAdbHLn7JQAA</XPD:REF>
<XPD:REF name="Associations[1]">Zq/mZjg0gUqF2/o9/OEjrgAA</XPD:REF>
<XPD:ATTR name="#Attributes" type="integer">5</XPD:ATTR>
<XPD:OBJ name="Attributes[0]" type="UMLAttribute" guid="NUF1SEm7JkO1PrJKsLgOBgAA">
<XPD:ATTR name="Name" type="string">Card playerHand[]</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkProtected</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[1]" type="UMLAttribute" guid="5UV8MTxh6UeWbtNFNPudFQAA">
<XPD:ATTR name="Name" type="string">StringBuilder handString</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkProtected</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[2]" type="UMLAttribute" guid="re9H+VbTDUWRXVriFu2joQAA">
<XPD:ATTR name="Name" type="string">int topCardIndex</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[3]" type="UMLAttribute" guid="ti9OJQXFGEa5jM0Vt2dXRQAA">
<XPD:ATTR name="Name" type="string">int numAces</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[4]" type="UMLAttribute" guid="5RrNh68RcUuJ+zyfS2awbAAA">
<XPD:ATTR name="Name" type="string">Deck deck</XPD:ATTR>
<XPD:ATTR name="Visibility" type="UMLVisibilityKind">vkPrivate</XPD:ATTR>
<XPD:REF name="Owner">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[5]" type="UMLClass" guid="DW9h3uomw0GVnWNohhl/LwAA">
<XPD:ATTR name="Name" type="string">BJCustomer</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">lKnhGh/MeUqRVuvJQbTWKgAA</XPD:REF>
<XPD:REF name="Views[1]">9tGozfmAn0qgeJdn13c/pAAA</XPD:REF>
<XPD:REF name="Views[2]">YIfcH6STlk2N8/gCbLW6oAAA</XPD:REF>
<XPD:REF name="Views[3]">jPhfkxHb3kiF6mbctiyKOAAA</XPD:REF>
<XPD:ATTR name="#Generalizations" type="integer">2</XPD:ATTR>
<XPD:REF name="Generalizations[0]">59HbSN4dv0eIeIWCde/BXwAA</XPD:REF>
<XPD:REF name="Generalizations[1]">g+WROHXs/0OWVCfl7EonzQAA</XPD:REF>
<XPD:ATTR name="#Specializations" type="integer">2</XPD:ATTR>
<XPD:REF name="Specializations[0]">59HbSN4dv0eIeIWCde/BXwAA</XPD:REF>
<XPD:REF name="Specializations[1]">UBcsmxqn7k2T/i9YSQ+qJwAA</XPD:REF>
<XPD:ATTR name="#Associations" type="integer">1</XPD:ATTR>
<XPD:REF name="Associations[0]">XqgiYbwL50yXN3bmSv92NAAA</XPD:REF>
<XPD:ATTR name="#Attributes" type="integer">3</XPD:ATTR>
<XPD:OBJ name="Attributes[0]" type="UMLAttribute" guid="xCr6aMuFxUinT7KASPERJAAA">
<XPD:ATTR name="Name" type="string">int NumWins</XPD:ATTR>
<XPD:REF name="Owner">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[1]" type="UMLAttribute" guid="cNsl6JQs5EOox1retDi1ggAA">
<XPD:ATTR name="Name" type="string">int NumLosses</XPD:ATTR>
<XPD:REF name="Owner">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[2]" type="UMLAttribute" guid="nPXEo6aBXEejVS20XBfZVgAA">
<XPD:ATTR name="Name" type="string">int NumTies</XPD:ATTR>
<XPD:REF name="Owner">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[6]" type="UMLClass" guid="7Uwpw/8muESDZZqNt7SGsAAA">
<XPD:ATTR name="Name" type="string">BJDealer</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">B4diEkk+nkmKtREidfG/QwAA</XPD:REF>
<XPD:REF name="Views[1]">c8Bx0ct+GUS5OPm7ryHIgwAA</XPD:REF>
<XPD:REF name="Views[2]">+OqjNPW7Jk2oxVK7SP/1wgAA</XPD:REF>
<XPD:REF name="Views[3]">hJYIYa0rGUSJAyqCSL8xwAAA</XPD:REF>
<XPD:ATTR name="#Generalizations" type="integer">1</XPD:ATTR>
<XPD:REF name="Generalizations[0]">mh3oO2GSREWNQdysmIHJwAAA</XPD:REF>
<XPD:ATTR name="#Operations" type="integer">1</XPD:ATTR>
<XPD:OBJ name="Operations[0]" type="UMLOperation" guid="tufEwPxOSEO8Kt58s/b7nAAA">
<XPD:ATTR name="Name" type="string">flipCard</XPD:ATTR>
<XPD:REF name="Owner">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
</XPD:OBJ>
<XPD:ATTR name="#Associations" type="integer">3</XPD:ATTR>
<XPD:REF name="Associations[0]">RjHMO39k60ahfXVYCmIeEAAA</XPD:REF>
<XPD:REF name="Associations[1]">BN8lmQqZ4UaDJ7LsU6wyvwAA</XPD:REF>
<XPD:REF name="Associations[2]">1BZo7DAnYUOsYJwR55ZXfAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[7]" type="UMLGeneralization" guid="59HbSN4dv0eIeIWCde/BXwAA">
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:REF name="Child">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
<XPD:REF name="Parent">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[8]" type="UMLGeneralization" guid="UBcsmxqn7k2T/i9YSQ+qJwAA">
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:REF name="Child">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
<XPD:REF name="Parent">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[9]" type="UMLGeneralization" guid="g+WROHXs/0OWVCfl7EonzQAA">
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:REF name="Child">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
<XPD:REF name="Parent">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">7Gwbl0tdxEW1kU5oAG9AewAA</XPD:REF>
<XPD:REF name="Views[1]">RMAPnUFxoUeZieCOCw8bfwAA</XPD:REF>
<XPD:REF name="Views[2]">n2s5dL6kuEiBIcoyUqkNHQAA</XPD:REF>
<XPD:REF name="Views[3]">rQyiuvEHnkqvtT7/0B1xnAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[10]" type="UMLGeneralization" guid="mh3oO2GSREWNQdysmIHJwAAA">
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:REF name="Child">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
<XPD:REF name="Parent">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">TtpQFxZYckueADg2QRUKHAAA</XPD:REF>
<XPD:REF name="Views[1]">TAwFEpDcIU+4HGQaTlQhxAAA</XPD:REF>
<XPD:REF name="Views[2]">VRodPfIeUEaqXJCI4KzaOAAA</XPD:REF>
<XPD:REF name="Views[3]">12s0wS+XgkOvWRVU/N2D+gAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[11]" type="UMLAssociation" guid="hWUA2Wufg0eaetuOb3PH3AAA">
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="RjHMO39k60ahfXVYCmIeEAAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">hWUA2Wufg0eaetuOb3PH3AAA</XPD:REF>
<XPD:REF name="Participant">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="BN8lmQqZ4UaDJ7LsU6wyvwAA">
<XPD:REF name="Association">hWUA2Wufg0eaetuOb3PH3AAA</XPD:REF>
<XPD:REF name="Participant">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[12]" type="UMLAssociation" guid="NiEFldmAPU+SwsJJ+ZS6WQAA">
<XPD:ATTR name="Name" type="string">Customer</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">GqYXSyKOsEK9wUizD5EdXQAA</XPD:REF>
<XPD:REF name="Views[1]">oFQsTF98FUKfHvt3kO4ulQAA</XPD:REF>
<XPD:REF name="Views[2]">rWEx+v7RhEO5WP4qrBj0GQAA</XPD:REF>
<XPD:REF name="Views[3]">wGu/AdDe9U6WUjrwZ5LzYgAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="Gbq2t5XJJkmLtSL9M//h+AAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">NiEFldmAPU+SwsJJ+ZS6WQAA</XPD:REF>
<XPD:REF name="Participant">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">+a17yx8CCECBWf/I77qbWAAA</XPD:REF>
<XPD:REF name="Views[1]">UN6V34aZiE+hrnM//8BRgAAA</XPD:REF>
<XPD:REF name="Views[2]">exQMNCbsLkSLCbCfjbM8HAAA</XPD:REF>
<XPD:REF name="Views[3]">5KRz9uSQtkqJPvsc3oGIQAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="XqgiYbwL50yXN3bmSv92NAAA">
<XPD:REF name="Association">NiEFldmAPU+SwsJJ+ZS6WQAA</XPD:REF>
<XPD:REF name="Participant">DW9h3uomw0GVnWNohhl/LwAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">gUyl07IpmEaCr8JCXVE9UAAA</XPD:REF>
<XPD:REF name="Views[1]">lNyErVwOrUan58wUIq/7OAAA</XPD:REF>
<XPD:REF name="Views[2]">bxx3+7UQSkeSz4AxxIZcoQAA</XPD:REF>
<XPD:REF name="Views[3]">wG0ET3t9A0aMG4v+6nITWwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[13]" type="UMLAssociation" guid="Rz+AOm/xnUmGeNIDGgon0AAA">
<XPD:ATTR name="Name" type="string">Dealer</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">gB7bsMzdtE2xF6cfiL1a6AAA</XPD:REF>
<XPD:REF name="Views[1]">QzCGPsYMB0+SE2ifYg9V1gAA</XPD:REF>
<XPD:REF name="Views[2]">jtul7VJvFkeHzx//taISPgAA</XPD:REF>
<XPD:REF name="Views[3]">hUELIjZPn0yvInWN0TJEdgAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="Ya+FdbYPL0GferQ0TMtpXgAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">Rz+AOm/xnUmGeNIDGgon0AAA</XPD:REF>
<XPD:REF name="Participant">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">jDlcI7lB70yppAXy9+jeyAAA</XPD:REF>
<XPD:REF name="Views[1]">33VWE688rEutYJ+8BEW2YwAA</XPD:REF>
<XPD:REF name="Views[2]">Wl4z/bqi00amLHp1zHKcFAAA</XPD:REF>
<XPD:REF name="Views[3]">f/ZOVDMSQEebv/GOoZM7cQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="1BZo7DAnYUOsYJwR55ZXfAAA">
<XPD:REF name="Association">Rz+AOm/xnUmGeNIDGgon0AAA</XPD:REF>
<XPD:REF name="Participant">7Uwpw/8muESDZZqNt7SGsAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">NEFzYir0bUeDscTauUl5RwAA</XPD:REF>
<XPD:REF name="Views[1]">Aa3Rb0VJoEqb26n9eEXQIQAA</XPD:REF>
<XPD:REF name="Views[2]">oHg1zDj3mkKGTvsfrkdVqwAA</XPD:REF>
<XPD:REF name="Views[3]">gdwzf19NZEOTLM9BBL4Q/AAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[14]" type="UMLAssociation" guid="uccfh+thtE2gTJM4hUSm+wAA">
<XPD:ATTR name="Name" type="string">deck</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="uWF1/tSKf0qNbl645NpAQgAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">uccfh+thtE2gTJM4hUSm+wAA</XPD:REF>
<XPD:REF name="Participant">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="ZkcT0q7WVEGlZ2ZwryD5VgAA">
<XPD:REF name="Association">uccfh+thtE2gTJM4hUSm+wAA</XPD:REF>
<XPD:REF name="Participant">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[15]" type="UMLInterface" guid="3wOQAvk0IU2MRORbFBF58gAA">
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[16]" type="UMLObject" guid="BfaXkbmYqki/7u3MUx281QAA">
<XPD:ATTR name="Name" type="string">deck</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[17]" type="UMLDependency" guid="e/PVmFInJ0SAUoK7sX5kIgAA">
<XPD:ATTR name="Name" type="string">deck</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:REF name="Client">86O1RveyFk+lo6p6kHuP4QAA</XPD:REF>
<XPD:REF name="Supplier">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">CO+QoU1W00WaE+3Je0VtFgAA</XPD:REF>
<XPD:REF name="Views[1]">zpIUqPOe0kuYADmaBrWEEQAA</XPD:REF>
<XPD:REF name="Views[2]">JWZ4SiDcQ0uk3vJgf+Bn9QAA</XPD:REF>
<XPD:REF name="Views[3]">pEeY6g0VmkGQ8Swssqy0PwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[18]" type="UMLClass" guid="uQBIZwnnu0qfAOG0/qI9NwAA">
<XPD:ATTR name="Name" type="string">Card</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">YZuKxT4b3UyecSca1VwyEAAA</XPD:REF>
<XPD:REF name="Views[1]">Ozd9mQK670aNTwdHwgYciwAA</XPD:REF>
<XPD:REF name="Views[2]">uyKKD0uw5EGdHy/oz6sHLgAA</XPD:REF>
<XPD:REF name="Views[3]">njnOslnvw0+36aS3moeW+wAA</XPD:REF>
<XPD:ATTR name="#Operations" type="integer">1</XPD:ATTR>
<XPD:OBJ name="Operations[0]" type="UMLOperation" guid="LOYbFGs4Q0+THAOFTUwoIwAA">
<XPD:ATTR name="Name" type="string">ToString</XPD:ATTR>
<XPD:REF name="Owner">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
<XPD:ATTR name="#Associations" type="integer">3</XPD:ATTR>
<XPD:REF name="Associations[0]">KOe9ebdVEkq8qOxuXaGNtQAA</XPD:REF>
<XPD:REF name="Associations[1]">qb4uALT++k2UEzNykaLDhgAA</XPD:REF>
<XPD:REF name="Associations[2]">3+Qy5bIo1EGf8kRnu0utLgAA</XPD:REF>
<XPD:ATTR name="#Attributes" type="integer">3</XPD:ATTR>
<XPD:OBJ name="Attributes[0]" type="UMLAttribute" guid="G6P8gUOpSUy84KKwDq9H0AAA">
<XPD:ATTR name="Name" type="string">Suit</XPD:ATTR>
<XPD:REF name="Owner">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[1]" type="UMLAttribute" guid="TP/SIUsWoU6/H/xjgxZLVwAA">
<XPD:ATTR name="Name" type="string">Rank</XPD:ATTR>
<XPD:REF name="Owner">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Attributes[2]" type="UMLAttribute" guid="B9vE1bmiPkqTFDG/l1LmOAAA">
<XPD:ATTR name="Name" type="string">FaceUp</XPD:ATTR>
<XPD:REF name="Owner">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[19]" type="UMLAssociation" guid="csg8Voyq4UGij62y+Z/NDgAA">
<XPD:ATTR name="Name" type="string">deck</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">object</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="VQB9Yl+FHEem6koJ2FySgAAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">csg8Voyq4UGij62y+Z/NDgAA</XPD:REF>
<XPD:REF name="Participant">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="KOe9ebdVEkq8qOxuXaGNtQAA">
<XPD:REF name="Association">csg8Voyq4UGij62y+Z/NDgAA</XPD:REF>
<XPD:REF name="Participant">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[20]" type="UMLAssociation" guid="SyZtRDBrmUSKwK0OcttDYwAA">
<XPD:ATTR name="Name" type="string">deck</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">object[]</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">a3wy3sazrUqSvLyo5XpYpAAA</XPD:REF>
<XPD:REF name="Views[1]">ovlVjznwzE23F9+FlwGtAgAA</XPD:REF>
<XPD:REF name="Views[2]">BEd7ffwI0ESgoDojenj/1gAA</XPD:REF>
<XPD:REF name="Views[3]">OMj5iDknvk+is9YibMXksgAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="ViF76epeqka5NAanwRnmnwAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">SyZtRDBrmUSKwK0OcttDYwAA</XPD:REF>
<XPD:REF name="Participant">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">xJWxJUn0lEiRcwUt3jr9QgAA</XPD:REF>
<XPD:REF name="Views[1]">hkZn11Y9s0Khw+2jFKhM+wAA</XPD:REF>
<XPD:REF name="Views[2]">DPKgqnIn806hBMNKaJgHZQAA</XPD:REF>
<XPD:REF name="Views[3]">eikXJLI0FE6N7B0OrUFLwQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="qb4uALT++k2UEzNykaLDhgAA">
<XPD:REF name="Association">SyZtRDBrmUSKwK0OcttDYwAA</XPD:REF>
<XPD:REF name="Participant">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">WXHUL8QQ5EWkkVhhkRA4gwAA</XPD:REF>
<XPD:REF name="Views[1]">knvqMYWkv0y0nwWIQkXnWQAA</XPD:REF>
<XPD:REF name="Views[2]">iNKyf5zql0KtK1+NsRebvAAA</XPD:REF>
<XPD:REF name="Views[3]">J+cMULQfN0aFPAFmb91+QQAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[21]" type="UMLAssociation" guid="uUZFKckQTku1vkqZvf1lWQAA">
<XPD:ATTR name="Name" type="string">deck</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">2JEFPqiLOkSVJaTLgF2xTQAA</XPD:REF>
<XPD:REF name="Views[1]">k8tN76vh3kiMI2N8PL0jvAAA</XPD:REF>
<XPD:REF name="Views[2]">zx26Qg5TD0iCcUhCfhxAbwAA</XPD:REF>
<XPD:REF name="Views[3]">whlqCGi8cUu5E7TRozYDtwAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="hrsZDDUzxUieDAdbHLn7JQAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">uUZFKckQTku1vkqZvf1lWQAA</XPD:REF>
<XPD:REF name="Participant">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">xsoduHNnLEybAduRu4tIPQAA</XPD:REF>
<XPD:REF name="Views[1]">8r5BHVPJ20ydsk1BObZMJgAA</XPD:REF>
<XPD:REF name="Views[2]">b5XTbZpqR0qO4Xt+p8Hd9AAA</XPD:REF>
<XPD:REF name="Views[3]">85FUDCMm/k+4yGR48aLtBwAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="MdaWZ6iawkuz5hYsqJGPqQAA">
<XPD:REF name="Association">uUZFKckQTku1vkqZvf1lWQAA</XPD:REF>
<XPD:REF name="Participant">DlwK1IcLzkGj9LEPfQ5ZwAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">TSiI2xnnKkuh7UH+WUS2nwAA</XPD:REF>
<XPD:REF name="Views[1]">n9rmBL/wmk+aO2Duiey9uAAA</XPD:REF>
<XPD:REF name="Views[2]">MjSwBl4OL0mgu0xK8U+oKwAA</XPD:REF>
<XPD:REF name="Views[3]">1daLgQoAcE2D2xEzksZATgAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[22]" type="UMLAssociation" guid="9wyc9DSsgkKgk4tmPYVA8QAA">
<XPD:ATTR name="Name" type="string">playerHand[]</XPD:ATTR>
<XPD:REF name="Namespace">L4iAr+GseUKAdqRPNqYtnAAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">JIFaop+zgUeuSFnKsD79SgAA</XPD:REF>
<XPD:REF name="Views[1]">QacInGxedkm2cXyIwD3O9wAA</XPD:REF>
<XPD:REF name="Views[2]">3+eUJPrYfEqNS/J3AKympgAA</XPD:REF>
<XPD:REF name="Views[3]">mex810CVq0mMssz3tpWv1wAA</XPD:REF>
<XPD:ATTR name="#Connections" type="integer">2</XPD:ATTR>
<XPD:OBJ name="Connections[0]" type="UMLAssociationEnd" guid="Zq/mZjg0gUqF2/o9/OEjrgAA">
<XPD:ATTR name="IsNavigable" type="boolean">False</XPD:ATTR>
<XPD:REF name="Association">9wyc9DSsgkKgk4tmPYVA8QAA</XPD:REF>
<XPD:REF name="Participant">n2kB6QWlskWNMBwmO7q30AAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">YekCHEWIaE2xU0mmEKtDPwAA</XPD:REF>
<XPD:REF name="Views[1]">G2f8AG2i1kyI7qgNteTHFwAA</XPD:REF>
<XPD:REF name="Views[2]">hLiGN3jZH0uC+aipbjMw2gAA</XPD:REF>
<XPD:REF name="Views[3]">OLVUW7oMJkGG8btVCvQMVQAA</XPD:REF>
</XPD:OBJ>
<XPD:OBJ name="Connections[1]" type="UMLAssociationEnd" guid="3+Qy5bIo1EGf8kRnu0utLgAA">
<XPD:REF name="Association">9wyc9DSsgkKgk4tmPYVA8QAA</XPD:REF>
<XPD:REF name="Participant">uQBIZwnnu0qfAOG0/qI9NwAA</XPD:REF>
<XPD:ATTR name="#Views" type="integer">4</XPD:ATTR>
<XPD:REF name="Views[0]">gvZAXGmY1kOXMJsFOnODgwAA</XPD:REF>
<XPD:REF name="Views[1]">P4SZF/RZIEagvEGHtAzptwAA</XPD:REF>
<XPD:REF name="Views[2]">WUP/Dd2xh0WUPGlmpaclcQAA</XPD:REF>
<XPD:REF name="Views[3]">Hs1uk9odAk6K5B1NGeljNQAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[3]" type="UMLModel" guid="S6+bqUjZ5UKn61J08uUw2wAA">
<XPD:ATTR name="Name" type="string">Implementation Model</XPD:ATTR>
<XPD:ATTR name="StereotypeProfile" type="string">UMLStandard</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">implementationModel</XPD:ATTR>
<XPD:REF name="Namespace">r4jm53ELH0e/uTmA5zPrbgAA</XPD:REF>
<XPD:ATTR name="#OwnedDiagrams" type="integer">1</XPD:ATTR>
<XPD:OBJ name="OwnedDiagrams[0]" type="UMLComponentDiagram" guid="XdAf7+MQZEK07luud3eTRAAA">
<XPD:ATTR name="Name" type="string">Main</XPD:ATTR>
<XPD:REF name="DiagramOwner">S6+bqUjZ5UKn61J08uUw2wAA</XPD:REF>
<XPD:OBJ name="DiagramView" type="UMLComponentDiagramView" guid="cLCRnNDVD0OegPMLEzqkXwAA">
<XPD:REF name="Model">XdAf7+MQZEK07luud3eTRAAA</XPD:REF>
<XPD:REF name="Diagram">XdAf7+MQZEK07luud3eTRAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
<XPD:OBJ name="OwnedElements[4]" type="UMLModel" guid="HnlRqzstuUyKcXyNwbk+dAAA">
<XPD:ATTR name="Name" type="string">Deployment Model</XPD:ATTR>
<XPD:ATTR name="StereotypeProfile" type="string">UMLStandard</XPD:ATTR>
<XPD:ATTR name="StereotypeName" type="string">deploymentModel</XPD:ATTR>
<XPD:REF name="Namespace">r4jm53ELH0e/uTmA5zPrbgAA</XPD:REF>
<XPD:ATTR name="#OwnedDiagrams" type="integer">1</XPD:ATTR>
<XPD:OBJ name="OwnedDiagrams[0]" type="UMLDeploymentDiagram" guid="5g1vs4iqckOIN+NfS4JpIAAA">
<XPD:ATTR name="Name" type="string">Main</XPD:ATTR>
<XPD:REF name="DiagramOwner">HnlRqzstuUyKcXyNwbk+dAAA</XPD:REF>
<XPD:OBJ name="DiagramView" type="UMLDeploymentDiagramView" guid="I6aeCsQYr0meFLh4zX/j1AAA">
<XPD:REF name="Model">5g1vs4iqckOIN+NfS4JpIAAA</XPD:REF>
<XPD:REF name="Diagram">5g1vs4iqckOIN+NfS4JpIAAA</XPD:REF>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
</XPD:OBJ>
</XPD:BODY>
</XPD:PROJECT>

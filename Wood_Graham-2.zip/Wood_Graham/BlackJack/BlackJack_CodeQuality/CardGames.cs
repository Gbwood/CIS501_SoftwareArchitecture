﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack_CodeQuality
{
    class CardGames
    {
        static void Main(string[] args)
        {
            BlackJack bj = new BlackJack();
            bj.Go();
        }
    }

    
}
